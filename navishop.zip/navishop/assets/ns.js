( function () {
	const cfg = window.NS || {};
	const freeAt = Number( cfg.freeAt ) || 5000;
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.ns-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'ns-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'ns-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => toast( '✓ Added to your cart' ) );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your cart' ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
		if ( cart && cart.totals ) renderBar( money( cart.totals.total_items, cart.totals ) );
	}

	// id is the product, or the chosen colour's variation id.
	async function addToCart( id, btn ) {
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			const res = await fetch( cfg.store + 'cart/add-item', {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', Nonce: nonce },
				body: JSON.stringify( { id: Number( id ), quantity: 1 } ),
			} );
			const cart = await res.json();
			if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your cart. Please try again.' ) );
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-ns-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.nsAdd, b );
	} );

	/* WhatsApp orders ---------------------------------------------------- */
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		return '• ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ( it.quantity > 1 ? ' × ' + it.quantity : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-ns-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your cart is empty.' );
				return;
			}
			const lines = [ 'Hi Navi Shop, I\'d like to order:' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Subtotal: ' + fmt( money( cart.totals.total_items, cart.totals ) ) );
			lines.push( 'Payment: cash on delivery' );
			lines.push( 'Deliver to: ' );
			const url = 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your cart. Please try again.' );
		}
	} );

	/* Product page: colour swatches ------------------------------------- */
	// Turns WooCommerce's colour/design dropdown into buttons (the dropdown stays in the form,
	// hidden, so WooCommerce still swaps the photo, price and stock for the chosen colour).
	const SW = [ [ 'rose gold', '#E6A57E' ], [ 'rose', '#E6A57E' ], [ 'gold', '#D4AF37' ], [ 'champagne', '#E8D9A8' ], [ 'silver', '#C9CED6' ], [ 'white', '#F4F4F5' ], [ 'cream', '#EFE6CF' ], [ 'ice blue', '#A5D8E6' ], [ 'navy', '#1E3A8A' ], [ 'blue', '#2563EB' ], [ 'green', '#15803D' ], [ 'black', '#111111' ], [ 'coffee', '#5B3A29' ], [ 'brown', '#7C4A2D' ], [ 'tan', '#B7814F' ], [ 'grey', '#8A8F98' ], [ 'pink', '#C9968F' ] ];
	function swatchCss( label ) {
		let l = String( label ).toLowerCase();
		const found = [];
		SW.forEach( ( [ w, hex ] ) => {
			const i = l.indexOf( w );
			if ( i > -1 ) {
				found.push( [ i, hex ] );
				l = l.slice( 0, i ) + ' '.repeat( w.length ) + l.slice( i + w.length );
			}
		} );
		found.sort( ( a, b ) => a[ 0 ] - b[ 0 ] );
		if ( ! found.length ) return '#444';
		return found.length > 1 ? 'linear-gradient(135deg, ' + found[ 0 ][ 1 ] + ' 50%, ' + found[ 1 ][ 1 ] + ' 50%)' : found[ 0 ][ 1 ];
	}
	function initSwatches() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.nsSw ) return;
			sel.dataset.nsSw = '1';
			const isDesign = sel.name === 'attribute_design';
			const wrap = document.createElement( 'div' );
			wrap.className = 'ns-sw' + ( isDesign ? ' ns-sw--design' : '' );
			wrap.setAttribute( 'role', 'radiogroup' );
			const opts = Array.from( sel.options ).filter( ( o ) => o.value );
			wrap.innerHTML = opts.map( ( o ) => '<button type="button" role="radio" aria-checked="false" data-v="' + esc( o.value ) + '">' + ( isDesign ? '' : '<i style="background:' + swatchCss( o.text ) + '"></i>' ) + '<span>' + esc( o.text ) + '</span></button>' ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'ns-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				const on = b.dataset.v === sel.value;
				b.classList.toggle( 'is-on', on );
				b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
				updateWaProduct( sel.closest( 'form' ) );
			} );
			paint();
			updateWaProduct( sel.closest( 'form' ) );
		} );
		// Hide WooCommerce's "Clear" link: a colour is always chosen.
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
	}
	// The product page's WhatsApp button names the colour the customer picked.
	function updateWaProduct( form ) {
		const a = document.querySelector( '[data-ns-wa-product]' );
		if ( ! a || ! form ) return;
		const picked = $$( 'select[name^="attribute_"]', form ).map( ( s ) => s.value ).filter( Boolean ).join( ', ' );
		const msg = 'Hi Navi Shop, I\'d like the ' + a.dataset.nsWaProduct + ( picked ? ' in ' + picked : '' ) + ' (' + a.dataset.nsWaPrice + '). ' + a.dataset.nsWaUrl;
		a.href = 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( msg );
	}

	/* Saved watches ------------------------------------------------------ */
	const KEY = 'ns-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-ns-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.nsWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-ns-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-ns-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.nsWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your wishlist' : '♥ Saved to <a href="' + esc( cfg.home || '/' ) + 'wishlist/">your wishlist</a>' );
		if ( b.closest( '[data-ns-wishlist]' ) ) renderWishlist();
	} );

	// Add button for a product: variable products need a colour first, so they link to the product.
	const buyButton = ( p ) => {
		if ( ! p.is_purchasable || ! p.is_in_stock ) return '<a class="wp-element-button" href="' + esc( p.permalink ) + '">View</a>';
		if ( p.type === 'variable' ) {
			const attr = ( p.attributes || [] ).find( ( a ) => a.has_variations );
			return '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose ' + esc( attr ? plain( attr.name ).toLowerCase() : 'colour' ) + '</a>';
		}
		return '<button type="button" class="wp-element-button" data-ns-add="' + p.id + '">Add to cart</button>';
	};

	async function renderWishlist() {
		const box = document.querySelector( '[data-ns-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		if ( ! ids.length ) {
			box.innerHTML = '<div class="ns-empty"><p>Nothing saved yet. Tap the ♥ on any watch to keep it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse the collection</a></div>';
			return;
		}
		try {
			const res = await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' );
			const items = await res.json();
			box.innerHTML = '<div class="ns-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				return '<article class="ns-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<button type="button" class="ns-heart is-on" data-ns-wish="' + p.id + '" aria-label="Remove from wishlist" aria-pressed="true">' + heart + '</button>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><div class="ns-wish-price">' + p.price_html + '</div>' + buyButton( p ) + '</article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your saved watches. Please refresh the page.</p>';
		}
	}

	/* Quick view --------------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-ns-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'ns-qv' );
		const body = dlg && dlg.querySelector( '[data-ns-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="ns-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.nsQv ) ).json();
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '" data-img-id="' + im.id + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="ns-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-ns-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const brand = p.brands && p.brands[ 0 ] ? p.brands[ 0 ].name : '';
			const attr = ( p.attributes || [] ).find( ( a ) => a.has_variations );
			let choose = '';
			let buy;
			if ( ! p.is_purchasable || ! p.is_in_stock ) {
				buy = '<span class="ns-badge ns-badge--out">Sold out</span>';
			} else if ( attr && p.variations && p.variations.length ) {
				// One button per colour; each carries its variation id for the cart.
				const isDesign = plain( attr.name ).toLowerCase() === 'design';
				choose = '<p class="ns-qv__label">' + esc( plain( attr.name ) ) + ': <strong data-ns-qv-picked></strong></p><div class="ns-sw' + ( isDesign ? ' ns-sw--design' : '' ) + '">' + p.variations.map( ( v, i ) => {
					const val = v.attributes && v.attributes[ 0 ] ? v.attributes[ 0 ].value : '';
					const term = ( attr.terms || [] ).find( ( t ) => t.slug === val || t.name === val );
					const label = term ? plain( term.name ) : val;
					return '<button type="button" data-ns-qv-var="' + v.id + '" data-label="' + esc( label ) + '"' + ( i ? '' : ' class="is-on"' ) + '>' + ( isDesign ? '' : '<i style="background:' + swatchCss( label ) + '"></i>' ) + '<span>' + esc( label ) + '</span></button>';
				} ).join( '' ) + '</div>';
				buy = '<button type="button" class="wp-element-button" data-ns-add="' + p.variations[ 0 ].id + '" data-ns-qv-buy>Add to cart</button>';
			} else {
				buy = '<button type="button" class="wp-element-button" data-ns-add="' + p.id + '">Add to cart</button>';
			}
			body.innerHTML = '<div class="ns-qv__grid"><div class="ns-qv__media"><div class="ns-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="ns-qv__info">' + ( brand ? '<p class="ns-eyebrow">' + esc( plain( brand ) ) + '</p>' : '' ) + '<h2>' + p.name + '</h2><div class="ns-qv__price">' + p.price_html + '</div>' +
				'<div class="ns-qv__desc">' + ( p.short_description || '' ) + '</div>' + choose +
				'<div class="ns-qv__actions">' + buy + '<a class="ns-link" href="' + esc( p.permalink ) + '">Full details →</a></div></div></div>';
			const first = body.querySelector( '[data-ns-qv-var]' );
			if ( first ) pickQvVariation( first, p );
			body.nsProduct = p;
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this watch. Please try again.</p>';
		}
	} );
	// Variation photos: the Store API lists variations without images, so fetch the chosen one.
	async function pickQvVariation( btn, p ) {
		const box = btn.closest( '[data-ns-qv-body]' );
		$$( '[data-ns-qv-var]', box ).forEach( ( b ) => b.classList.toggle( 'is-on', b === btn ) );
		const picked = box.querySelector( '[data-ns-qv-picked]' );
		if ( picked ) picked.textContent = btn.dataset.label;
		const buy = box.querySelector( '[data-ns-qv-buy]' );
		if ( buy ) buy.dataset.nsAdd = btn.dataset.nsQvVar;
		try {
			const v = await ( await fetch( cfg.store + 'products/' + btn.dataset.nsQvVar ) ).json();
			const img = v.images && v.images[ 0 ];
			if ( ! img ) return;
			const main = $$( '.ns-qv__main img', box );
			const hit = main.findIndex( ( im ) => Number( im.dataset.imgId ) === img.id );
			if ( hit > -1 ) main.forEach( ( im, i ) => ( im.hidden = i !== hit ) );
			if ( buy && ! v.is_in_stock ) {
				buy.disabled = true;
				buy.textContent = 'Sold out in this ' + ( ( p.attributes || [] ).find( ( a ) => a.has_variations ) ? plain( p.attributes.find( ( a ) => a.has_variations ).name ).toLowerCase() : 'colour' );
			} else if ( buy ) {
				buy.disabled = false;
				buy.textContent = 'Add to cart';
			}
		} catch ( e ) {}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-ns-qv-var]' );
		if ( ! b ) return;
		const box = b.closest( '[data-ns-qv-body]' );
		pickQvVariation( b, box && box.nsProduct ? box.nsProduct : {} );
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-ns-qv-img]' );
		if ( ! t ) return;
		const main = t.closest( '.ns-qv__media' ).querySelectorAll( '.ns-qv__main img' );
		main.forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.nsQvImg ) ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.ns-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.ns-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'ns-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const res = await fetch( cfg.store + 'products?search=' + encodeURIComponent( q ) + '&per_page=6' );
						const items = await res.json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail ) + '" alt="">' : '' ) + '<span>' + p.name + '<small>' + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>No watch matches “' + esc( q ) + '”. <a href="https://wa.me/' + esc( cfg.wa ) + '?text=' + encodeURIComponent( 'Hi Navi Shop, do you have a ' + q + '?' ) + '">Ask us on WhatsApp</a></p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Free-delivery bar ------------------------------------------------- */
	function renderBar( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi delivery</strong>'
			: "<strong>You've unlocked free Nairobi delivery!</strong>";
		$$( '[data-ns-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="ns-freebar__track"><div class="ns-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}
	// The cart page and the mini cart change quantities without a reload; follow them.
	function watchCart() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		let last = null;
		data.subscribe( () => {
			const totals = data.select( 'wc/store/cart' ).getCartTotals();
			if ( totals && totals.total_items !== undefined ) {
				const sub = money( totals.total_items, totals );
				if ( sub !== last ) {
					last = sub;
					renderBar( sub );
				}
			}
		} );
	}

	function init() {
		paintWish();
		renderWishlist();
		initSearch();
		initSwatches();
		watchCart();
		// Cards and the mini cart re-render client-side; keep hearts, swatches and the bar in sync.
		new MutationObserver( () => {
			paintWish();
			initSwatches();
		} ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
