<?php
/**
 * Navi Shop WATCHes child theme.
 */

const NS_WHATSAPP      = '254741653165';
const NS_PHONE         = '0741 653 165';
const NS_FREE_DELIVERY = 5000; // PLACEHOLDER: free Nairobi delivery from this cart value (matches the shipping zone in setup.php).
const NS_FONTS         = 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,500&family=Inter:wght@400;500;600;700&display=swap';

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'ns-fonts', NS_FONTS, [], null );
	wp_enqueue_style( 'ns', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'ns', $uri . '/assets/ns.js', [], filemtime( $dir . '/assets/ns.js' ), true );
	wp_localize_script( 'ns', 'NS', [
		'store'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'   => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'home'   => esc_url_raw( home_url( '/' ) ),
		'wa'     => NS_WHATSAPP,
		'freeAt' => NS_FREE_DELIVERY,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'ns-fonts', NS_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way shops here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function ns_wa_link( $text = '' ) {
	return 'https://wa.me/' . NS_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function ns_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

/**
 * Specs as label => value pairs, from the "Label: value" lines staff type on the product screen.
 */
function ns_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_ns_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

/** The product's colour/design choice: [ label, options ] or null. */
function ns_choice( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return null;
	}
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->get_variation() ) {
			return [ wc_attribute_label( $attr->get_name(), $product ), $attr->get_options() ];
		}
	}
	return null;
}

/** Units left across the product (all its colours). */
function ns_stock_left( WC_Product $product ) {
	if ( $product->is_type( 'variable' ) ) {
		$n = 0;
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( $v && $v->managing_stock() ) {
				$n += max( 0, (int) $v->get_stock_quantity() );
			}
		}
		return $n;
	}
	return $product->managing_stock() ? max( 0, (int) $product->get_stock_quantity() ) : null;
}

function ns_badges_html( WC_Product $product ) {
	$h = '';
	if ( ! $product->is_in_stock() ) {
		$h .= '<span class="ns-badge ns-badge--out">Sold out</span>';
	} else {
		if ( $product->is_on_sale() ) {
			$reg  = (float) ( $product->is_type( 'variable' ) ? $product->get_variation_regular_price( 'min' ) : $product->get_regular_price() );
			$sale = (float) $product->get_price();
			if ( $reg > $sale && $sale > 0 ) {
				$h .= '<span class="ns-badge ns-badge--sale">' . round( ( 1 - $sale / $reg ) * 100 ) . '% off</span>';
			}
		}
		$left = ns_stock_left( $product );
		if ( $left !== null && $left > 0 && $left <= 2 ) {
			$h .= '<span class="ns-badge ns-badge--low">Only ' . $left . ' left</span>';
		}
	}
	return $h ? '<div class="ns-badges">' . $h . '</div>' : '';
}

// Rough colour for a swatch dot, from the words in an option name ("Blue & rose gold").
function ns_swatch_css( $label ) {
	$map = [
		'rose gold' => '#E6A57E', 'rose' => '#E6A57E', 'gold' => '#D4AF37', 'champagne' => '#E8D9A8', 'silver' => '#C9CED6', 'white' => '#F4F4F5',
		'cream' => '#EFE6CF', 'ice blue' => '#A5D8E6', 'navy' => '#1E3A8A', 'blue' => '#2563EB', 'green' => '#15803D', 'black' => '#111111',
		'coffee' => '#5B3A29', 'brown' => '#7C4A2D', 'tan' => '#B7814F', 'grey' => '#8A8F98', 'pink' => '#C9968F',
	];
	$l = strtolower( $label );
	$found = [];
	foreach ( $map as $word => $hex ) {
		if ( ( $pos = strpos( $l, $word ) ) !== false ) {
			$found[ $pos ] = $hex;
			$l = substr_replace( $l, str_repeat( ' ', strlen( $word ) ), $pos, strlen( $word ) );
		}
	}
	ksort( $found );
	$found = array_values( $found );
	if ( ! $found ) {
		return '#444';
	}
	return count( $found ) > 1 ? "linear-gradient(135deg, {$found[0]} 50%, {$found[1]} 50%)" : $found[0];
}

function ns_swatches_html( WC_Product $product, $max = 6 ) {
	$choice = ns_choice( $product );
	if ( ! $choice ) {
		return '';
	}
	[ $label, $opts ] = $choice;
	if ( strtolower( $label ) === 'design' ) {
		return '<p class="ns-swatches ns-swatches--text">' . count( $opts ) . ' designs to choose from</p>';
	}
	$h = '<div class="ns-swatches" aria-label="' . esc_attr( count( $opts ) . ' colours' ) . '">';
	foreach ( array_slice( $opts, 0, $max ) as $o ) {
		$h .= '<span class="ns-swatch" style="background:' . esc_attr( ns_swatch_css( $o ) ) . '" title="' . esc_attr( $o ) . '"></span>';
	}
	if ( count( $opts ) > $max ) {
		$h .= '<em>+' . ( count( $opts ) - $max ) . '</em>';
	}
	return $h . '</div>';
}

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to cart' );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_in_stock() ) {
		return $t;
	}
	$choice = $p->is_type( 'variable' ) ? ns_choice( $p ) : null;
	return $choice ? 'Choose ' . strtolower( $choice[0] ) : 'Add to cart';
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	if ( ! $product->is_in_stock() ) {
		return 'Sold out in this colour';
	}
	$n = $product->managing_stock() ? (int) $product->get_stock_quantity() : null;
	return $n !== null && $n <= 2 ? 'Only ' . $n . ' left – order soon' : 'In stock in Nairobi';
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

// Key specs above the add-to-cart button.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$specs = ns_specs( $product->get_id() );
	$keys  = array_slice( array_intersect_key( $specs, array_flip( [ 'Movement', 'Display', 'Case', 'Strap', 'Water resistance', 'Glass' ] ) ), 0, 4 );
	if ( ! $keys ) {
		return;
	}
	echo '<ul class="ns-keyspecs">';
	foreach ( $keys as $k => $v ) {
		echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
	}
	echo '</ul>';
} );

// Order on WhatsApp and buying promises under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$msg = 'Hi Navi Shop, I\'d like the ' . $product->get_name() . ' (' . ns_money( $product->get_price() ) . '). ' . $product->get_permalink();
	echo '<a class="ns-wa-order" data-ns-wa-product="' . esc_attr( $product->get_name() ) . '" data-ns-wa-price="' . esc_attr( ns_money( $product->get_price() ) ) . '" data-ns-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( ns_wa_link( $msg ) ) . '" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>Order via WhatsApp</a>';

	echo '<div class="ns-promise"><div><span aria-hidden="true">📦</span><p><strong>Cash on delivery</strong>Check the watch when it arrives, then pay.</p></div><div><span aria-hidden="true">⚡</span><p><strong>Same-day Nairobi delivery</strong>Free on orders over ' . esc_html( ns_money( NS_FREE_DELIVERY ) ) . '. Countrywide courier in 1–2 days.</p></div><div><span aria-hidden="true">✆</span><p><strong>Questions?</strong>WhatsApp us for more photos or a video of this watch.</p></div></div>';
} );

// Specs, care and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$specs = ns_specs( $product->get_id() );
	if ( $specs ) {
		$tabs['ns_specs'] = [
			'title'    => 'Specifications',
			'priority' => 5,
			'callback' => function () use ( $specs ) {
				echo '<table class="ns-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table>';
			},
		];
	}
	$tabs['ns_care'] = [
		'title'    => 'Watch care',
		'priority' => 25,
		'callback' => function () {
			echo '<ul><li><strong>Water:</strong> "water resistant" and 3 ATM watches cope with rain, splashes and hand-washing. Take them off before a shower, swim or sauna, and never press the buttons or pull the crown when wet.</li><li><strong>Quartz watches</strong> run on a battery that usually lasts 1–3 years. When the seconds hand starts jumping in 4-second steps, it is time for a new one.</li><li><strong>Automatic watches</strong> wind themselves as you wear them. If one stops after a few days off the wrist, give the crown 20–30 turns.</li><li><strong>Leather straps</strong> last longer kept away from water, sweat and perfume. Steel and mesh can be wiped with a soft damp cloth.</li><li><strong>Keep it away from magnets</strong> such as speakers and phone cases, which can upset the timekeeping.</li></ul>';
		},
	];
	$tabs['ns_delivery'] = [
		'title'    => 'Delivery & cash on delivery',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Cash on delivery:</strong> we bring the watch to you, you check it, and you pay when it is in your hand. We call first to confirm your order.</li><li><strong>Nairobi:</strong> same-day delivery for KSh 250, free on orders over ' . esc_html( ns_money( NS_FREE_DELIVERY ) ) . '.</li><li><strong>Upcountry:</strong> courier to any county in 1–2 days for KSh 400.</li><li><strong>WhatsApp orders:</strong> tap "Order via WhatsApp" and we will sort everything in the chat.</li></ul>';
		},
	];
	// The description already shows next to the photos.
	unset( $tabs['description'], $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function ns_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

const NS_HEART = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

// Hover image (first gallery photo), wishlist heart and quick view on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = ns_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'ns-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$extra = sprintf(
		'<button type="button" class="ns-heart" data-ns-wish="%1$d" aria-label="Save %2$s to your wishlist" aria-pressed="false">%3$s</button><button type="button" class="ns-qv-btn" data-ns-qv="%1$d" aria-label="Quick view of %2$s">Quick view</button>',
		$product->get_id(),
		esc_attr( $product->get_name() ),
		NS_HEART
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Brand above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = ns_card_product( $instance );
	$brands  = $product && taxonomy_exists( 'product_brand' ) ? wp_get_post_terms( $product->get_id(), 'product_brand', [ 'fields' => 'names' ] ) : [];
	return ( $brands && ! is_wp_error( $brands ) ? '<p class="ns-card-brand">' . esc_html( $brands[0] ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Colour swatches, sale and stock badges around the price.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = ns_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	return ns_swatches_html( $product ) . ns_badges_html( $product ) . $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function ns_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// "Shop by style": one tile per category, shown with a photo of its first watch not already
// used by an earlier tile (a watch can sit in several categories).
add_shortcode( 'ns_styles', function () {
	$h    = '<div class="ns-styles">';
	$used = [];
	foreach ( ns_categories() as $t ) {
		$list  = wc_get_products( [ 'category' => [ $t->slug ], 'limit' => 10, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
		$pick  = current( array_filter( $list, fn( $p ) => ! in_array( $p->get_id(), $used, true ) ) ) ?: ( $list[0] ?? null );
		$used[] = $pick ? $pick->get_id() : 0;
		$img   = $pick ? $pick->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h .= sprintf(
			'<a class="ns-style" href="%s"><span class="ns-style__img">%s</span><span class="ns-style__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_url( get_term_link( $t ) ),
			$img,
			esc_html( $t->name ),
			esc_html( sprintf( _n( '%d watch', '%d watches', $t->count ), $t->count ) )
		);
	}
	return $h . '</div>';
} );

function ns_straps() {
	$out = [];
	foreach ( [ 'stainless-steel', 'leather', 'mesh', 'rubber' ] as $slug ) {
		$t = get_term_by( 'slug', $slug, 'product_tag' );
		if ( $t && $t->count ) {
			$out[] = $t;
		}
	}
	return $out;
}

// Strap filter pills for the home page.
add_shortcode( 'ns_straps', function () {
	$h = '<div class="ns-strap-pills"><span>Shop by strap</span>';
	foreach ( ns_straps() as $t ) {
		$h .= ns_chip( $t->name, get_term_link( $t ), false, $t->count );
	}
	return $h . '</div>';
} );

function ns_brands() {
	if ( ! taxonomy_exists( 'product_brand' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'product_brand', 'hide_empty' => true, 'orderby' => 'name' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

add_shortcode( 'ns_brands', function () {
	$brands = ns_brands();
	if ( ! $brands ) {
		return '';
	}
	$h = '<div class="ns-brands">';
	foreach ( $brands as $t ) {
		$h .= '<a href="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . '</a>';
	}
	return $h . '</div>';
} );

function ns_chip( $label, $url, $on, $count = null, $small = false ) {
	return sprintf( '<a class="ns-chip%s%s" href="%s">%s%s</a>', $small ? ' ns-chip--sm' : '', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}

// Style, strap and brand chips above shop, category, tag, brand and search results.
add_shortcode( 'ns_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="ns-filters" aria-label="Filter watches"><div class="ns-filters__row">';
	$h .= ns_chip( 'All watches', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( ns_categories() as $t ) {
		$h .= ns_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	$h .= '</div><div class="ns-filters__row"><span>Strap</span>';
	foreach ( ns_straps() as $t ) {
		$h .= ns_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count, true );
	}
	$brands = ns_brands();
	if ( $brands ) {
		$h .= '</div><div class="ns-filters__row"><span>Brand</span>';
		foreach ( $brands as $t ) {
			$h .= ns_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, null, true );
		}
	}
	return $h . '</div></nav>';
} );

add_shortcode( 'ns_wishlist', function () {
	return '<div class="ns-wishlist" data-ns-wishlist><p class="ns-small">Loading your saved watches…</p></div>';
} );

// Quick view pop-up, filled in by ns.js.
add_action( 'wp_footer', function () {
	echo '<dialog id="ns-qv" class="ns-dialog ns-qv" aria-label="Quick view"><form method="dialog"><button class="ns-dialog__close" aria-label="Close">×</button></form><div data-ns-qv-body></div></dialog>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function ns_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, NS_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / NS_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>' . ns_money( $left ) . '</strong> more for <strong>free Nairobi delivery</strong>'
		: '<strong>You\'ve unlocked free Nairobi delivery!</strong>';
	return '<div class="ns-freebar" data-ns-freebar>' . $msg . '<div class="ns-freebar__track"><div class="ns-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
function ns_cart_note_html() {
	return '<div class="ns-cart-note"><strong>Cash on delivery 📦</strong> Check your watch when it arrives, then pay.</div>';
}
function ns_wa_cart_html() {
	return '<button type="button" class="ns-wa-cart" data-ns-wa-cart>Send this order to us on WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => ns_freebar_html() . ns_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . ns_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', ns_freebar_html() . '$1', $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="ns-wa-cart-wrap">' . ns_wa_cart_html() . '</div>' );

// A landmark helps the rider find the customer.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'ns/landmark',
		'label'    => 'Building, estate or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Tracking code and WhatsApp summary on the order confirmation page.
function ns_tracking_code( WC_Order $order ) {
	return 'NS-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function ns_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Navi Shop, I just placed order ' . ns_tracking_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		$lines[] = '• ' . $item->get_name() . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' ) . ' – ' . ns_money( $item->get_total() );
	}
	$lines[] = 'Delivery: ' . $order->get_shipping_method() . ( (float) $order->get_shipping_total() > 0 ? ' (' . ns_money( $order->get_shipping_total() ) . ')' : '' );
	$lines[] = 'Total: ' . ns_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city() ] ) ) );
	if ( $address ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return ns_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="ns-thanks"><p class="ns-thanks__code">Order tracking number <strong>' . esc_html( ns_tracking_code( $order ) ) . '</strong></p><p>We\'ll call you shortly to confirm and arrange delivery. For the quickest reply, send your order summary to us on WhatsApp.</p><a class="wp-element-button ns-wa-btn" href="' . esc_attr( ns_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">Send order summary to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Tracking number:</strong> ' . esc_html( ns_tracking_code( $order ) ) . '</p>';
} );

// VIP Club newsletter. Staff see the list under WooCommerce → VIP Club.
add_action( 'admin_post_nopriv_ns_subscribe', 'ns_subscribe' );
add_action( 'admin_post_ns_subscribe', 'ns_subscribe' );
function ns_subscribe() {
	check_admin_referer( 'ns_subscribe' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$back  = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'ns_sub', 'invalid', $back ) . '#newsletter' );
		exit;
	}
	$list = get_option( 'ns_subscribers', [] );
	$list[ strtolower( $email ) ] = current_time( 'mysql' );
	update_option( 'ns_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'ns_sub', 'ok', $back ) . '#newsletter' );
	exit;
}

add_shortcode( 'ns_newsletter', function () {
	$state = sanitize_key( $_GET['ns_sub'] ?? '' );
	if ( $state === 'ok' ) {
		return '<p class="ns-news-ok"><strong>Welcome to the VIP Club.</strong> New arrivals and offers reach you first.</p>';
	}
	$err = $state === 'invalid' ? '<p class="ns-news-err">Please enter a valid email address.</p>' : '';
	return '<form class="ns-news-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="ns_subscribe">'
		. wp_nonce_field( 'ns_subscribe', '_wpnonce', true, false )
		. '<input type="email" name="email" required placeholder="Your email address" aria-label="Email address">'
		. '<button class="wp-element-button" type="submit">Join the club</button>'
		. '</form>' . $err;
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'VIP Club', 'VIP Club', 'manage_woocommerce', 'ns-subscribers', function () {
		$list = get_option( 'ns_subscribers', [] );
		echo '<div class="wrap"><h1>VIP Club (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email</th><th>Signed up</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $email => $when ) {
			echo '<tr><td>' . esc_html( $email ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

// Staff edit the spec sheet on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_textarea_input( [ 'id' => '_ns_specs', 'label' => 'Specifications', 'rows' => 7, 'description' => 'One per line, as "Label: value", e.g. "Strap: Stainless steel". Movement, Display, Case and Strap also show next to the price.' ] );
	echo '<p class="form-field"><em>Colours: add them under Attributes (e.g. "Colour" with "Blue | Black"), then create one variation per colour with its own photo and stock. Strap: tick Stainless Steel, Leather, Mesh or Rubber in the Product tags box.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	if ( isset( $_POST['_ns_specs'] ) ) {
		$product->update_meta_data( '_ns_specs', sanitize_textarea_field( wp_unslash( $_POST['_ns_specs'] ) ) );
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and we need a phone number to arrange delivery.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate / Town (e.g. Westlands, Rongai, Nakuru)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#0D0D0D\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
